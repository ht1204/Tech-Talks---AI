import React, { useState, useRef, useEffect } from 'react';

const DEV_AGENT_SYSTEM_PROMPT = `You are an AI Software Development Agent. You help developers by:

1. UNDERSTANDING their coding requirements and goals
2. ARCHITECTING solutions with proper design patterns
3. IMPLEMENTING clean, well-structured code
4. TESTING and debugging to ensure quality
5. DOCUMENTING for maintainability

## Your Tools (Capabilities):
- ANALYZE_CODE: Parse and understand existing code
- WRITE_CODE: Generate new code files or snippets
- EXECUTE_CODE: Run code and show output
- DEBUG_CODE: Identify issues and suggest fixes
- SEARCH_DOCS: Find relevant documentation
- REFACTOR_CODE: Improve code quality
- GENERATE_TESTS: Create unit tests
- EXPLAIN_CODE: Add documentation and comments

## Response Format:
ALWAYS structure your response like this:

**🎯 Understanding Your Request:**
[Summarize the coding task in 1-2 sentences]

**🏗️ My Approach:**
[List 2-4 numbered steps you'll take]

**🔧 Tools Used:**
[List which tools you're using: ANALYZE_CODE, WRITE_CODE, etc.]

**💻 Implementation:**
[Provide the code in a code block]

**🧪 Testing/Validation:**
[Show how to test or validate the code]

**📝 Explanation:**
[Brief explanation of key decisions]

## Code Quality Rules:
- Write clean, readable code with proper naming
- Include error handling where appropriate
- Add inline comments for complex logic
- Follow language-specific best practices
- Suggest tests for critical functionality

## Behavior:
- Ask clarifying questions if requirements are unclear
- Explain your reasoning and design decisions
- Be explicit about trade-offs
- Show your thinking process`;

export default function DevAgentDemo() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [agentPhase, setAgentPhase] = useState('idle');
  const [toolsUsed, setToolsUsed] = useState([]);
  const chatEndRef = useRef(null);

  const phases = [
    { id: 'analyzing', icon: '🔍', label: 'Analyzing' },
    { id: 'planning', icon: '🏗️', label: 'Architecting' },
    { id: 'coding', icon: '💻', label: 'Implementing' },
    { id: 'testing', icon: '🧪', label: 'Testing' },
    { id: 'documenting', icon: '📚', label: 'Documenting' }
  ];

  const examplePrompts = [
    "Create a Python function to validate email addresses with unit tests",
    "Build a React hook for managing form state with validation",
    "Write a REST API endpoint in Node.js for user authentication",
    "Debug this: for i in range(10) print(i)",
    "Refactor: fetch(url).then(r => r.json()).then(console.log)"
  ];

  const toolDescriptions = {
    'analyze_code': '🔍 Analyzing',
    'write_code': '✍️ Writing',
    'execute_code': '▶️ Running',
    'debug_code': '🐛 Debugging',
    'search_docs': '📖 Searching',
    'refactor_code': '♻️ Refactoring',
    'generate_tests': '🧪 Testing',
    'explain_code': '💬 Documenting'
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const simulatePhases = async (taskType) => {
    const configs = {
      'create': [
        { phase: 'analyzing', delay: 500, tools: ['analyze_code'] },
        { phase: 'planning', delay: 700, tools: ['search_docs'] },
        { phase: 'coding', delay: 1200, tools: ['write_code'] },
        { phase: 'testing', delay: 800, tools: ['generate_tests'] },
        { phase: 'documenting', delay: 400, tools: ['explain_code'] }
      ],
      'debug': [
        { phase: 'analyzing', delay: 600, tools: ['analyze_code'] },
        { phase: 'testing', delay: 800, tools: ['execute_code'] },
        { phase: 'coding', delay: 1000, tools: ['debug_code'] }
      ],
      'refactor': [
        { phase: 'analyzing', delay: 700, tools: ['analyze_code'] },
        { phase: 'planning', delay: 500, tools: ['search_docs'] },
        { phase: 'coding', delay: 1000, tools: ['refactor_code'] }
      ],
      'default': [
        { phase: 'analyzing', delay: 500, tools: ['analyze_code'] },
        { phase: 'coding', delay: 1000, tools: ['write_code'] },
        { phase: 'testing', delay: 500, tools: ['execute_code'] }
      ]
    };

    for (const { phase, delay, tools } of (configs[taskType] || configs['default'])) {
      setAgentPhase(phase);
      setToolsUsed(prev => [...prev, ...tools]);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  };

  const detectTaskType = (msg) => {
    const l = msg.toLowerCase();
    if (l.includes('debug') || l.includes('fix') || l.includes('error')) return 'debug';
    if (l.includes('refactor') || l.includes('improve')) return 'refactor';
    if (l.includes('create') || l.includes('build') || l.includes('write')) return 'create';
    return 'default';
  };

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsLoading(true);
    setToolsUsed([]);

    simulatePhases(detectTaskType(currentInput));

    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 2000,
          system: DEV_AGENT_SYSTEM_PROMPT,
          messages: [...messages, userMessage].map(m => ({ role: m.role, content: m.content }))
        })
      });

      const data = await response.json();
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: data.content?.[0]?.text || 'Error processing request.' 
      }]);
    } catch {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `⚠️ **Demo Mode** - API simulated.

**🎯 Understanding Your Request:**
You want help with: "${currentInput}"

**🏗️ My Approach:**
1. Analyze requirements
2. Design solution
3. Implement code
4. Test and validate

**🔧 Tools Used:**
\`ANALYZE_CODE\` → \`WRITE_CODE\` → \`EXECUTE_CODE\` → \`GENERATE_TESTS\`

**💻 Implementation:**
\`\`\`python
# In live demo, actual code appears here
def example_solution():
    """Your requested implementation"""
    pass
\`\`\`

**📝 Connect API for full functionality!**` 
      }]);
    }

    setIsLoading(false);
    setAgentPhase('idle');
  };

  const formatMessage = (content) => {
    let formatted = content.replace(/```(\w+)?\n([\s\S]*?)```/g, (_, lang, code) => 
      `<div style="background:#1e293b;border-radius:8px;margin:12px 0;border:1px solid #334155;overflow:hidden">
        <div style="background:#334155;padding:6px 12px;font-size:12px;color:#94a3b8;font-family:monospace">${lang || 'code'}</div>
        <pre style="padding:12px;margin:0;overflow-x:auto"><code style="font-family:Consolas,monospace;font-size:13px;color:#e2e8f0">${code.trim().replace(/</g,'&lt;').replace(/>/g,'&gt;')}</code></pre>
      </div>`
    );
    formatted = formatted.replace(/`([^`]+)`/g, '<code style="background:#334155;padding:2px 6px;border-radius:4px;font-family:monospace;font-size:12px;color:#10b981">$1</code>');
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong style="color:#5eead4">$1</strong>');
    return formatted.replace(/\n/g, '<br/>');
  };

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100vh',background:'#0f172a',color:'#e2e8f0',fontFamily:'system-ui,sans-serif'}}>
      {/* Header */}
      <div style={{background:'linear-gradient(to right,#059669,#0d9488,#0891b2)',padding:'16px',boxShadow:'0 4px 6px rgba(0,0,0,0.3)'}}>
        <h1 style={{margin:0,fontSize:'24px',fontWeight:'bold'}}>💻 AI Software Development Agent</h1>
        <p style={{margin:'4px 0 0',fontSize:'14px',opacity:0.9}}>Demonstrating AI Agent capabilities for coding tasks</p>
      </div>

      {/* Phase Indicator */}
      <div style={{background:'#1e293b',borderBottom:'1px solid #334155',padding:'12px'}}>
        <div style={{display:'flex',justifyContent:'space-between',maxWidth:'700px',margin:'0 auto'}}>
          {phases.map((phase, idx) => {
            const isActive = agentPhase === phase.id;
            const isCompleted = phases.findIndex(p => p.id === agentPhase) > idx;
            return (
              <div key={phase.id} style={{display:'flex',alignItems:'center'}}>
                <div style={{display:'flex',flexDirection:'column',alignItems:'center',transform:isActive?'scale(1.1)':'scale(1)',transition:'all 0.3s'}}>
                  <div style={{
                    width:'48px',height:'48px',borderRadius:'8px',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'20px',
                    background:isActive?'#10b981':isCompleted?'#059669':'#334155',
                    color:isActive||isCompleted?'white':'#64748b',
                    boxShadow:isActive?'0 0 20px rgba(16,185,129,0.4)':'none'
                  }}>
                    {isCompleted ? '✓' : phase.icon}
                  </div>
                  <span style={{fontSize:'11px',marginTop:'4px',color:isActive?'#34d399':isCompleted?'#10b981':'#64748b'}}>{phase.label}</span>
                </div>
                {idx < phases.length - 1 && (
                  <div style={{width:'40px',height:'2px',margin:'0 8px',background:isCompleted?'#10b981':'#334155',borderRadius:'2px'}} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Tools */}
      {toolsUsed.length > 0 && (
        <div style={{background:'rgba(16,185,129,0.1)',borderBottom:'1px solid #065f46',padding:'8px 16px'}}>
          <span style={{color:'#34d399',fontSize:'13px',marginRight:'8px'}}>🛠️ Tools:</span>
          {[...new Set(toolsUsed)].map((tool, idx) => (
            <span key={idx} style={{background:'#064e3b',color:'#6ee7b7',padding:'4px 8px',borderRadius:'4px',fontSize:'12px',marginRight:'6px',fontFamily:'monospace'}}>
              {toolDescriptions[tool] || tool}
            </span>
          ))}
        </div>
      )}

      {/* Chat */}
      <div style={{flex:1,overflowY:'auto',padding:'16px'}}>
        {messages.length === 0 && (
          <div style={{textAlign:'center',padding:'32px 0'}}>
            <div style={{fontSize:'48px',marginBottom:'16px'}}>🚀</div>
            <h2 style={{fontSize:'20px',marginBottom:'8px'}}>AI-Powered Development Assistant</h2>
            <p style={{color:'#94a3b8',marginBottom:'24px',maxWidth:'500px',margin:'0 auto 24px'}}>
              Watch how an AI agent handles coding tasks through: analyzing, architecting, implementing, testing, and documenting.
            </p>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))',gap:'8px',maxWidth:'700px',margin:'0 auto'}}>
              {examplePrompts.map((prompt, idx) => (
                <button key={idx} onClick={() => setInput(prompt)} style={{
                  padding:'12px',textAlign:'left',background:'#1e293b',border:'1px solid #334155',borderRadius:'8px',
                  color:'#cbd5e1',fontSize:'13px',cursor:'pointer',transition:'all 0.2s'
                }}
                onMouseOver={e => e.target.style.borderColor = '#10b981'}
                onMouseOut={e => e.target.style.borderColor = '#334155'}>
                  <span style={{color:'#10b981'}}>→</span> {prompt}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, idx) => (
          <div key={idx} style={{display:'flex',justifyContent:msg.role==='user'?'flex-end':'flex-start',marginBottom:'16px'}}>
            <div style={{
              maxWidth:'85%',padding:'16px',borderRadius:'12px',
              background:msg.role==='user'?'#059669':'#1e293b',
              border:msg.role==='user'?'none':'1px solid #334155'
            }}>
              {msg.role === 'assistant' && (
                <div style={{display:'flex',alignItems:'center',gap:'8px',marginBottom:'12px',paddingBottom:'8px',borderBottom:'1px solid #334155'}}>
                  <span>🤖</span>
                  <span style={{fontSize:'13px',color:'#34d399',fontWeight:'500'}}>Dev Agent</span>
                </div>
              )}
              <div style={{fontSize:'14px',lineHeight:'1.6'}} dangerouslySetInnerHTML={{__html: formatMessage(msg.content)}} />
            </div>
          </div>
        ))}

        {isLoading && (
          <div style={{display:'flex',justifyContent:'flex-start',marginBottom:'16px'}}>
            <div style={{background:'#1e293b',border:'1px solid #334155',padding:'16px',borderRadius:'12px'}}>
              <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
                <span>🤖</span>
                <span style={{color:'#34d399',fontSize:'13px'}}>Dev Agent</span>
                <span style={{color:'#64748b',fontSize:'13px',marginLeft:'8px',textTransform:'capitalize'}}>
                  {agentPhase === 'idle' ? 'Processing' : agentPhase}...
                </span>
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input */}
      <div style={{background:'#1e293b',borderTop:'1px solid #334155',padding:'16px'}}>
        <div style={{display:'flex',gap:'12px',maxWidth:'800px',margin:'0 auto'}}>
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyPress={e => e.key === 'Enter' && sendMessage()}
            placeholder="Describe what you want to build, fix, or improve..."
            disabled={isLoading}
            style={{
              flex:1,padding:'12px 16px',background:'#0f172a',border:'1px solid #334155',borderRadius:'8px',
              color:'#e2e8f0',fontSize:'14px',outline:'none'
            }}
          />
          <button onClick={sendMessage} disabled={isLoading || !input.trim()} style={{
            padding:'12px 24px',background:'#059669',color:'white',border:'none',borderRadius:'8px',
            fontWeight:'500',cursor:'pointer',opacity:isLoading||!input.trim()?0.5:1
          }}>
            {isLoading ? '⏳ Building...' : 'Send →'}
          </button>
        </div>
      </div>

      {/* Footer */}
      <div style={{background:'rgba(16,185,129,0.1)',borderTop:'1px solid #065f46',padding:'12px 16px'}}>
        <p style={{margin:0,fontSize:'13px',color:'#6ee7b7',textAlign:'center'}}>
          <strong>🎓 Demo:</strong> Analyzing → Architecting → Implementing → Testing → Documenting
        </p>
      </div>
    </div>
  );
}
